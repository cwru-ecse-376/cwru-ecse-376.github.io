
"use strict";

let AddSoundSource = require('./AddSoundSource.js')
let DeleteRfidTag = require('./DeleteRfidTag.js')
let AddThermalSource = require('./AddThermalSource.js')
let DeleteThermalSource = require('./DeleteThermalSource.js')
let LoadMap = require('./LoadMap.js')
let LoadExternalMap = require('./LoadExternalMap.js')
let MoveRobot = require('./MoveRobot.js')
let DeleteSoundSource = require('./DeleteSoundSource.js')
let RegisterGui = require('./RegisterGui.js')
let AddCO2Source = require('./AddCO2Source.js')
let DeleteCO2Source = require('./DeleteCO2Source.js')
let AddRfidTag = require('./AddRfidTag.js')

module.exports = {
  AddSoundSource: AddSoundSource,
  DeleteRfidTag: DeleteRfidTag,
  AddThermalSource: AddThermalSource,
  DeleteThermalSource: DeleteThermalSource,
  LoadMap: LoadMap,
  LoadExternalMap: LoadExternalMap,
  MoveRobot: MoveRobot,
  DeleteSoundSource: DeleteSoundSource,
  RegisterGui: RegisterGui,
  AddCO2Source: AddCO2Source,
  DeleteCO2Source: DeleteCO2Source,
  AddRfidTag: AddRfidTag,
};
