
"use strict";

let RobotMsg = require('./RobotMsg.js');
let ThermalSource = require('./ThermalSource.js');
let LaserSensorMsg = require('./LaserSensorMsg.js');
let RfidSensorMsg = require('./RfidSensorMsg.js');
let Noise = require('./Noise.js');
let CO2SourceVector = require('./CO2SourceVector.js');
let ThermalSourceVector = require('./ThermalSourceVector.js');
let ThermalSensorMeasurementMsg = require('./ThermalSensorMeasurementMsg.js');
let RfidSensorMeasurementMsg = require('./RfidSensorMeasurementMsg.js');
let KinematicMsg = require('./KinematicMsg.js');
let CO2SensorMsg = require('./CO2SensorMsg.js');
let SoundSensorMsg = require('./SoundSensorMsg.js');
let SoundSourceVector = require('./SoundSourceVector.js');
let SoundSensorMeasurementMsg = require('./SoundSensorMeasurementMsg.js');
let CO2Source = require('./CO2Source.js');
let RobotIndexedMsg = require('./RobotIndexedMsg.js');
let RobotIndexedVectorMsg = require('./RobotIndexedVectorMsg.js');
let RfidTagVector = require('./RfidTagVector.js');
let ThermalSensorMsg = require('./ThermalSensorMsg.js');
let SoundSource = require('./SoundSource.js');
let CO2SensorMeasurementMsg = require('./CO2SensorMeasurementMsg.js');
let FootprintMsg = require('./FootprintMsg.js');
let RfidTag = require('./RfidTag.js');
let SonarSensorMsg = require('./SonarSensorMsg.js');
let DeleteRobotAction = require('./DeleteRobotAction.js');
let DeleteRobotResult = require('./DeleteRobotResult.js');
let DeleteRobotFeedback = require('./DeleteRobotFeedback.js');
let RegisterRobotActionGoal = require('./RegisterRobotActionGoal.js');
let SpawnRobotResult = require('./SpawnRobotResult.js');
let DeleteRobotGoal = require('./DeleteRobotGoal.js');
let SpawnRobotActionGoal = require('./SpawnRobotActionGoal.js');
let RegisterRobotActionResult = require('./RegisterRobotActionResult.js');
let SpawnRobotGoal = require('./SpawnRobotGoal.js');
let SpawnRobotFeedback = require('./SpawnRobotFeedback.js');
let RegisterRobotResult = require('./RegisterRobotResult.js');
let SpawnRobotActionResult = require('./SpawnRobotActionResult.js');
let SpawnRobotActionFeedback = require('./SpawnRobotActionFeedback.js');
let DeleteRobotActionResult = require('./DeleteRobotActionResult.js');
let RegisterRobotFeedback = require('./RegisterRobotFeedback.js');
let SpawnRobotAction = require('./SpawnRobotAction.js');
let RegisterRobotGoal = require('./RegisterRobotGoal.js');
let RegisterRobotActionFeedback = require('./RegisterRobotActionFeedback.js');
let DeleteRobotActionFeedback = require('./DeleteRobotActionFeedback.js');
let RegisterRobotAction = require('./RegisterRobotAction.js');
let DeleteRobotActionGoal = require('./DeleteRobotActionGoal.js');

module.exports = {
  RobotMsg: RobotMsg,
  ThermalSource: ThermalSource,
  LaserSensorMsg: LaserSensorMsg,
  RfidSensorMsg: RfidSensorMsg,
  Noise: Noise,
  CO2SourceVector: CO2SourceVector,
  ThermalSourceVector: ThermalSourceVector,
  ThermalSensorMeasurementMsg: ThermalSensorMeasurementMsg,
  RfidSensorMeasurementMsg: RfidSensorMeasurementMsg,
  KinematicMsg: KinematicMsg,
  CO2SensorMsg: CO2SensorMsg,
  SoundSensorMsg: SoundSensorMsg,
  SoundSourceVector: SoundSourceVector,
  SoundSensorMeasurementMsg: SoundSensorMeasurementMsg,
  CO2Source: CO2Source,
  RobotIndexedMsg: RobotIndexedMsg,
  RobotIndexedVectorMsg: RobotIndexedVectorMsg,
  RfidTagVector: RfidTagVector,
  ThermalSensorMsg: ThermalSensorMsg,
  SoundSource: SoundSource,
  CO2SensorMeasurementMsg: CO2SensorMeasurementMsg,
  FootprintMsg: FootprintMsg,
  RfidTag: RfidTag,
  SonarSensorMsg: SonarSensorMsg,
  DeleteRobotAction: DeleteRobotAction,
  DeleteRobotResult: DeleteRobotResult,
  DeleteRobotFeedback: DeleteRobotFeedback,
  RegisterRobotActionGoal: RegisterRobotActionGoal,
  SpawnRobotResult: SpawnRobotResult,
  DeleteRobotGoal: DeleteRobotGoal,
  SpawnRobotActionGoal: SpawnRobotActionGoal,
  RegisterRobotActionResult: RegisterRobotActionResult,
  SpawnRobotGoal: SpawnRobotGoal,
  SpawnRobotFeedback: SpawnRobotFeedback,
  RegisterRobotResult: RegisterRobotResult,
  SpawnRobotActionResult: SpawnRobotActionResult,
  SpawnRobotActionFeedback: SpawnRobotActionFeedback,
  DeleteRobotActionResult: DeleteRobotActionResult,
  RegisterRobotFeedback: RegisterRobotFeedback,
  SpawnRobotAction: SpawnRobotAction,
  RegisterRobotGoal: RegisterRobotGoal,
  RegisterRobotActionFeedback: RegisterRobotActionFeedback,
  DeleteRobotActionFeedback: DeleteRobotActionFeedback,
  RegisterRobotAction: RegisterRobotAction,
  DeleteRobotActionGoal: DeleteRobotActionGoal,
};
