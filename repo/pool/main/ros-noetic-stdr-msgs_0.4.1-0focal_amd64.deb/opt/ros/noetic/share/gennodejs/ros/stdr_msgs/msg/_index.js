
"use strict";

let SoundSource = require('./SoundSource.js');
let SoundSourceVector = require('./SoundSourceVector.js');
let ThermalSensorMsg = require('./ThermalSensorMsg.js');
let ThermalSource = require('./ThermalSource.js');
let LaserSensorMsg = require('./LaserSensorMsg.js');
let CO2SourceVector = require('./CO2SourceVector.js');
let SoundSensorMsg = require('./SoundSensorMsg.js');
let ThermalSensorMeasurementMsg = require('./ThermalSensorMeasurementMsg.js');
let FootprintMsg = require('./FootprintMsg.js');
let RobotMsg = require('./RobotMsg.js');
let KinematicMsg = require('./KinematicMsg.js');
let RfidTagVector = require('./RfidTagVector.js');
let SoundSensorMeasurementMsg = require('./SoundSensorMeasurementMsg.js');
let RfidTag = require('./RfidTag.js');
let RfidSensorMsg = require('./RfidSensorMsg.js');
let RfidSensorMeasurementMsg = require('./RfidSensorMeasurementMsg.js');
let RobotIndexedMsg = require('./RobotIndexedMsg.js');
let Noise = require('./Noise.js');
let RobotIndexedVectorMsg = require('./RobotIndexedVectorMsg.js');
let SonarSensorMsg = require('./SonarSensorMsg.js');
let CO2SensorMsg = require('./CO2SensorMsg.js');
let ThermalSourceVector = require('./ThermalSourceVector.js');
let CO2SensorMeasurementMsg = require('./CO2SensorMeasurementMsg.js');
let CO2Source = require('./CO2Source.js');
let DeleteRobotFeedback = require('./DeleteRobotFeedback.js');
let DeleteRobotActionGoal = require('./DeleteRobotActionGoal.js');
let DeleteRobotGoal = require('./DeleteRobotGoal.js');
let RegisterRobotGoal = require('./RegisterRobotGoal.js');
let RegisterRobotActionResult = require('./RegisterRobotActionResult.js');
let SpawnRobotAction = require('./SpawnRobotAction.js');
let RegisterRobotActionGoal = require('./RegisterRobotActionGoal.js');
let SpawnRobotFeedback = require('./SpawnRobotFeedback.js');
let SpawnRobotActionFeedback = require('./SpawnRobotActionFeedback.js');
let RegisterRobotResult = require('./RegisterRobotResult.js');
let DeleteRobotActionResult = require('./DeleteRobotActionResult.js');
let RegisterRobotActionFeedback = require('./RegisterRobotActionFeedback.js');
let RegisterRobotAction = require('./RegisterRobotAction.js');
let RegisterRobotFeedback = require('./RegisterRobotFeedback.js');
let SpawnRobotGoal = require('./SpawnRobotGoal.js');
let DeleteRobotActionFeedback = require('./DeleteRobotActionFeedback.js');
let SpawnRobotActionResult = require('./SpawnRobotActionResult.js');
let DeleteRobotResult = require('./DeleteRobotResult.js');
let SpawnRobotResult = require('./SpawnRobotResult.js');
let SpawnRobotActionGoal = require('./SpawnRobotActionGoal.js');
let DeleteRobotAction = require('./DeleteRobotAction.js');

module.exports = {
  SoundSource: SoundSource,
  SoundSourceVector: SoundSourceVector,
  ThermalSensorMsg: ThermalSensorMsg,
  ThermalSource: ThermalSource,
  LaserSensorMsg: LaserSensorMsg,
  CO2SourceVector: CO2SourceVector,
  SoundSensorMsg: SoundSensorMsg,
  ThermalSensorMeasurementMsg: ThermalSensorMeasurementMsg,
  FootprintMsg: FootprintMsg,
  RobotMsg: RobotMsg,
  KinematicMsg: KinematicMsg,
  RfidTagVector: RfidTagVector,
  SoundSensorMeasurementMsg: SoundSensorMeasurementMsg,
  RfidTag: RfidTag,
  RfidSensorMsg: RfidSensorMsg,
  RfidSensorMeasurementMsg: RfidSensorMeasurementMsg,
  RobotIndexedMsg: RobotIndexedMsg,
  Noise: Noise,
  RobotIndexedVectorMsg: RobotIndexedVectorMsg,
  SonarSensorMsg: SonarSensorMsg,
  CO2SensorMsg: CO2SensorMsg,
  ThermalSourceVector: ThermalSourceVector,
  CO2SensorMeasurementMsg: CO2SensorMeasurementMsg,
  CO2Source: CO2Source,
  DeleteRobotFeedback: DeleteRobotFeedback,
  DeleteRobotActionGoal: DeleteRobotActionGoal,
  DeleteRobotGoal: DeleteRobotGoal,
  RegisterRobotGoal: RegisterRobotGoal,
  RegisterRobotActionResult: RegisterRobotActionResult,
  SpawnRobotAction: SpawnRobotAction,
  RegisterRobotActionGoal: RegisterRobotActionGoal,
  SpawnRobotFeedback: SpawnRobotFeedback,
  SpawnRobotActionFeedback: SpawnRobotActionFeedback,
  RegisterRobotResult: RegisterRobotResult,
  DeleteRobotActionResult: DeleteRobotActionResult,
  RegisterRobotActionFeedback: RegisterRobotActionFeedback,
  RegisterRobotAction: RegisterRobotAction,
  RegisterRobotFeedback: RegisterRobotFeedback,
  SpawnRobotGoal: SpawnRobotGoal,
  DeleteRobotActionFeedback: DeleteRobotActionFeedback,
  SpawnRobotActionResult: SpawnRobotActionResult,
  DeleteRobotResult: DeleteRobotResult,
  SpawnRobotResult: SpawnRobotResult,
  SpawnRobotActionGoal: SpawnRobotActionGoal,
  DeleteRobotAction: DeleteRobotAction,
};
