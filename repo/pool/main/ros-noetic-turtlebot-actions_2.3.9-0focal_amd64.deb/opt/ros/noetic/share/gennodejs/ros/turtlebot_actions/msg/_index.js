
"use strict";

let TurtlebotMoveActionFeedback = require('./TurtlebotMoveActionFeedback.js');
let FindFiducialActionFeedback = require('./FindFiducialActionFeedback.js');
let FindFiducialAction = require('./FindFiducialAction.js');
let TurtlebotMoveFeedback = require('./TurtlebotMoveFeedback.js');
let TurtlebotMoveActionResult = require('./TurtlebotMoveActionResult.js');
let TurtlebotMoveAction = require('./TurtlebotMoveAction.js');
let TurtlebotMoveActionGoal = require('./TurtlebotMoveActionGoal.js');
let FindFiducialFeedback = require('./FindFiducialFeedback.js');
let FindFiducialActionResult = require('./FindFiducialActionResult.js');
let TurtlebotMoveGoal = require('./TurtlebotMoveGoal.js');
let FindFiducialGoal = require('./FindFiducialGoal.js');
let TurtlebotMoveResult = require('./TurtlebotMoveResult.js');
let FindFiducialResult = require('./FindFiducialResult.js');
let FindFiducialActionGoal = require('./FindFiducialActionGoal.js');

module.exports = {
  TurtlebotMoveActionFeedback: TurtlebotMoveActionFeedback,
  FindFiducialActionFeedback: FindFiducialActionFeedback,
  FindFiducialAction: FindFiducialAction,
  TurtlebotMoveFeedback: TurtlebotMoveFeedback,
  TurtlebotMoveActionResult: TurtlebotMoveActionResult,
  TurtlebotMoveAction: TurtlebotMoveAction,
  TurtlebotMoveActionGoal: TurtlebotMoveActionGoal,
  FindFiducialFeedback: FindFiducialFeedback,
  FindFiducialActionResult: FindFiducialActionResult,
  TurtlebotMoveGoal: TurtlebotMoveGoal,
  FindFiducialGoal: FindFiducialGoal,
  TurtlebotMoveResult: TurtlebotMoveResult,
  FindFiducialResult: FindFiducialResult,
  FindFiducialActionGoal: FindFiducialActionGoal,
};
