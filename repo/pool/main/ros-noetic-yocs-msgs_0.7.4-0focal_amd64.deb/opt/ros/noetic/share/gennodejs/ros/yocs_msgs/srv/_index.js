
"use strict";

let WaypointListService = require('./WaypointListService.js')

module.exports = {
  WaypointListService: WaypointListService,
};
