
"use strict";

let TakePanorama = require('./TakePanorama.js')
let SetFollowState = require('./SetFollowState.js')

module.exports = {
  TakePanorama: TakePanorama,
  SetFollowState: SetFollowState,
};
