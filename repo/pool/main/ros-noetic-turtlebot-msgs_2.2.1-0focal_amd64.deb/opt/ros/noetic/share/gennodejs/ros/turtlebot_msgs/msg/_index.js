
"use strict";

let PanoramaImg = require('./PanoramaImg.js');

module.exports = {
  PanoramaImg: PanoramaImg,
};
