
"use strict";

let FindFiducialActionResult = require('./FindFiducialActionResult.js');
let FindFiducialAction = require('./FindFiducialAction.js');
let FindFiducialGoal = require('./FindFiducialGoal.js');
let TurtlebotMoveActionResult = require('./TurtlebotMoveActionResult.js');
let FindFiducialFeedback = require('./FindFiducialFeedback.js');
let TurtlebotMoveAction = require('./TurtlebotMoveAction.js');
let TurtlebotMoveGoal = require('./TurtlebotMoveGoal.js');
let TurtlebotMoveActionGoal = require('./TurtlebotMoveActionGoal.js');
let FindFiducialResult = require('./FindFiducialResult.js');
let FindFiducialActionGoal = require('./FindFiducialActionGoal.js');
let TurtlebotMoveResult = require('./TurtlebotMoveResult.js');
let FindFiducialActionFeedback = require('./FindFiducialActionFeedback.js');
let TurtlebotMoveActionFeedback = require('./TurtlebotMoveActionFeedback.js');
let TurtlebotMoveFeedback = require('./TurtlebotMoveFeedback.js');

module.exports = {
  FindFiducialActionResult: FindFiducialActionResult,
  FindFiducialAction: FindFiducialAction,
  FindFiducialGoal: FindFiducialGoal,
  TurtlebotMoveActionResult: TurtlebotMoveActionResult,
  FindFiducialFeedback: FindFiducialFeedback,
  TurtlebotMoveAction: TurtlebotMoveAction,
  TurtlebotMoveGoal: TurtlebotMoveGoal,
  TurtlebotMoveActionGoal: TurtlebotMoveActionGoal,
  FindFiducialResult: FindFiducialResult,
  FindFiducialActionGoal: FindFiducialActionGoal,
  TurtlebotMoveResult: TurtlebotMoveResult,
  FindFiducialActionFeedback: FindFiducialActionFeedback,
  TurtlebotMoveActionFeedback: TurtlebotMoveActionFeedback,
  TurtlebotMoveFeedback: TurtlebotMoveFeedback,
};
